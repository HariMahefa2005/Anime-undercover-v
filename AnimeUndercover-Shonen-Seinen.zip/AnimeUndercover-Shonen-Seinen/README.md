# Anime Undercover — Édition Shonen & Seinen (Photos Officielles)

Projet Android complet (`com.animeundercover.multiverse`) avec :
- **Catégories Shonen (60 paires), Seinen (35 paires) et Mixte (95 paires)**
- **Photos officielles des personnages** récupérées en direct depuis les bases de données d'anime (AniList / MyAnimeList) lors de la révélation des cartes et sur l'écran de fin de partie.
- **Workflow GitHub Actions auto-extracteur** : vous pouvez déposer directement ce fichier `.zip` dans votre dépôt GitHub !
